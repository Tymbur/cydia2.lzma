zst
===

A simple tool the check the status of a change in zuul


.. image:: screenshot.png
